#include <iostream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <limits>
#include <thread>
#include <mutex>
#include <atomic>
#include <chrono>
#include <cmath>
#include <algorithm>
#include <memory>
#include <tuple>
#include <string>

using namespace std;

// Constants
const double INF = numeric_limits<double>::infinity();

// Traffic Data Structure
struct TrafficData {
    double speed; // in km/h
    int volume;   // number of vehicles
    long timestamp;

    TrafficData(double s = 0, int v = 0, long ts = 0) 
        : speed(s), volume(v), timestamp(ts) {}
};

// Road Segment (Edge in graph)
struct RoadSegment {
    int from, to;
    double length; // in km
    double speed_limit; // in km/h
    double base_travel_time; // in minutes (length/speed_limit * 60)
    vector<TrafficData> historical_data;
    
    RoadSegment(int f, int t, double len, double limit)
        : from(f), to(t), length(len), speed_limit(limit), 
          base_travel_time((len / limit) * 60) {}
};

// Graph Node (Intersection)
struct Intersection {
    int id;
    string name;
    double latitude, longitude;

    Intersection(int i, string n, double lat, double lon)
        : id(i), name(n), latitude(lat), longitude(lon) {}
};

// Graph class for road network
class RoadNetwork {
private:
    vector<Intersection> intersections;
    unordered_map<int, vector<pair<int, shared_ptr<RoadSegment>>>> adj_list;
    mutex data_mutex;

public:
    // Add intersection to the network
    void addIntersection(int id, string name, double lat, double lon) {
        intersections.emplace_back(id, name, lat, lon);
    }

    // Add road segment between two intersections
    void addRoadSegment(int from, int to, double length, double speed_limit) {
        auto segment = make_shared<RoadSegment>(from, to, length, speed_limit);
        adj_list[from].emplace_back(to, segment);
        // For undirected/bidirectional roads
        adj_list[to].emplace_back(from, segment);
    }

    // Update traffic data for a road segment
    void updateTrafficData(int from, int to, double speed, int volume) {
        lock_guard<mutex> lock(data_mutex);
        long timestamp = chrono::system_clock::now().time_since_epoch().count();
        
        for (auto& neighbor : adj_list[from]) {
            if (neighbor.first == to) {
                neighbor.second->historical_data.emplace_back(speed, volume, timestamp);
                // Keep only recent data (e.g., last 1 hour)
                if (neighbor.second->historical_data.size() > 60) {
                    neighbor.second->historical_data.erase(neighbor.second->historical_data.begin());
                }
                break;
            }
        }
    }

    // Get current travel time for a road segment (in minutes)
    double getCurrentTravelTime(int from, int to) {
        lock_guard<mutex> lock(data_mutex);
        for (auto& neighbor : adj_list[from]) {
            if (neighbor.first == to) {
                if (neighbor.second->historical_data.empty()) {
                    return neighbor.second->base_travel_time;
                }
                // Use the most recent speed data
                double current_speed = neighbor.second->historical_data.back().speed;
                if (current_speed <= 0) return INF; // road closed or jammed
                return (neighbor.second->length / current_speed) * 60;
            }
        }
        return INF; // no such road
    }

    // Dijkstra's algorithm to find shortest path based on current traffic
    vector<int> findShortestPath(int start, int end) {
        priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> pq;
        unordered_map<int, double> dist;
        unordered_map<int, int> prev;
        
        for (const auto& intersection : intersections) {
            dist[intersection.id] = INF;
        }
        dist[start] = 0;
        pq.emplace(0, start);

        while (!pq.empty()) {
            auto current = pq.top();
            pq.pop();
            double current_dist = current.first;
            int u = current.second;

            if (u == end) break;
            if (current_dist > dist[u]) continue;

            for (auto& neighbor : adj_list[u]) {
                int v = neighbor.first;
                double travel_time = getCurrentTravelTime(u, v);
                if (travel_time == INF) continue;

                if (dist[v] > dist[u] + travel_time) {
                    dist[v] = dist[u] + travel_time;
                    prev[v] = u;
                    pq.emplace(dist[v], v);
                }
            }
        }

        // Reconstruct path
        vector<int> path;
        if (dist[end] == INF) return path; // no path found

        for (int at = end; at != start; at = prev[at]) {
            path.push_back(at);
        }
        path.push_back(start);
        reverse(path.begin(), path.end());

        return path;
    }

    // Get average speed for a road segment over a time interval
    double getAverageSpeed(int from, int to, long start_time, long end_time) {
        lock_guard<mutex> lock(data_mutex);
        for (auto& neighbor : adj_list[from]) {
            if (neighbor.first == to) {
                double total = 0;
                int count = 0;
                for (const auto& data : neighbor.second->historical_data) {
                    if (data.timestamp >= start_time && data.timestamp <= end_time) {
                        total += data.speed;
                        count++;
                    }
                }
                return count > 0 ? total / count : neighbor.second->speed_limit;
            }
        }
        return 0;
    }
};

// Traffic Sensor Simulator
class TrafficSensor {
private:
    RoadNetwork& network;
    atomic<bool> running{false};
    thread sensor_thread;

public:
    TrafficSensor(RoadNetwork& net) : network(net) {}

    void start() {
        running = true;
        sensor_thread = thread([this]() {
            while (running) {
                // Simulate random traffic updates
                int from = rand() % 10;
                int to = (from + 1 + rand() % 3) % 10;
                double speed = 30 + rand() % 70; // random speed between 30-100 km/h
                int volume = 1 + rand() % 10;    // random volume 1-10 vehicles
                
                network.updateTrafficData(from, to, speed, volume);
                
                this_thread::sleep_for(chrono::seconds(1));
            }
        });
    }

    void stop() {
        running = false;
        if (sensor_thread.joinable()) {
            sensor_thread.join();
        }
    }
};

// Segment Tree for efficient range queries on traffic data
class TrafficSegmentTree {
private:
    struct Node {
        long start_time, end_time;
        double min_speed, max_speed, sum_speed;
        int count;
        Node *left, *right;

        Node(long s, long e) 
            : start_time(s), end_time(e), min_speed(INF), max_speed(0), 
              sum_speed(0), count(0), left(nullptr), right(nullptr) {}
    };

    Node* root;

    Node* build(const vector<pair<long, double>>& data, long l, long r) {
        Node* node = new Node(data[l].first, data[r].first);
        if (l == r) {
            node->min_speed = node->max_speed = node->sum_speed = data[l].second;
            node->count = 1;
            return node;
        }

        long mid = l + (r - l) / 2;
        node->left = build(data, l, mid);
        node->right = build(data, mid + 1, r);

        node->min_speed = min(node->left->min_speed, node->right->min_speed);
        node->max_speed = max(node->left->max_speed, node->right->max_speed);
        node->sum_speed = node->left->sum_speed + node->right->sum_speed;
        node->count = node->left->count + node->right->count;

        return node;
    }

    void query(Node* node, long l, long r, double& min_s, double& max_s, double& sum_s, int& count) {
        if (node == nullptr || node->start_time > r || node->end_time < l) return;

        if (l <= node->start_time && node->end_time <= r) {
            min_s = min(min_s, node->min_speed);
            max_s = max(max_s, node->max_speed);
            sum_s += node->sum_speed;
            count += node->count;
            return;
        }

        query(node->left, l, r, min_s, max_s, sum_s, count);
        query(node->right, l, r, min_s, max_s, sum_s, count);
    }

public:
    TrafficSegmentTree(const vector<pair<long, double>>& data) {
        if (!data.empty()) {
            root = build(data, 0, data.size() - 1);
        } else {
            root = nullptr;
        }
    }

    ~TrafficSegmentTree() {
        // TODO: Implement proper tree deletion
    }

    tuple<double, double, double> queryRange(long start_time, long end_time) {
        double min_speed = INF, max_speed = 0, sum_speed = 0;
        int count = 0;
        query(root, start_time, end_time, min_speed, max_speed, sum_speed, count);
        double avg_speed = count > 0 ? sum_speed / count : 0;
        return make_tuple(min_speed, max_speed, avg_speed);
    }
};

// Main application
int main() {
    // Initialize road network
    RoadNetwork network;
    
    // Add intersections (nodes)
    for (int i = 0; i < 10; ++i) {
        network.addIntersection(i, "Intersection " + to_string(i), 0.0, 0.0);
    }
    
    // Add road segments (edges)
    for (int i = 0; i < 9; ++i) {
        network.addRoadSegment(i, i + 1, 1.5, 60); // 1.5km roads with 60km/h limit
    }
    network.addRoadSegment(9, 0, 2.0, 50); // circular connection
    
    // Start traffic sensors
    TrafficSensor sensor(network);
    sensor.start();
    
    // Let the system gather some data
    this_thread::sleep_for(chrono::seconds(3));
    
    // Example queries
    cout << "Finding shortest path from 0 to 5..." << endl;
    auto path = network.findShortestPath(0, 5);
    cout << "Path: ";
    for (int node : path) {
        cout << node << " ";
    }
    cout << endl;
    
    cout << "Current travel time from 0 to 1: " 
         << network.getCurrentTravelTime(0, 1) << " minutes" << endl;
    
    // Stop sensors
    sensor.stop();
    
    return 0;
}